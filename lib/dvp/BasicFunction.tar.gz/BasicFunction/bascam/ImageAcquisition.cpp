#include "ImageAcquisition.h"

QImageAcquisition::QImageAcquisition(dvpHandle &handle,QObject *parent) :
    QThread(parent)
{
    // 初始化成员变量
    m_handle = handle;
    m_bAcquireImg = false;
    pBuffer = NULL;
}

QImageAcquisition::~QImageAcquisition()
{

}

void QImageAcquisition::run()
{
    dvpStatus status;

    while(1)
    {
        if (m_bAcquireImg == false)
        {
            qDebug("quit thread!");
            break;
        }

        status = dvpGetFrame(m_handle, &m_pFrame, &pBuffer, m_uGrabTimeout);
        if (status == DVP_STATUS_OK)
        {
            m_threadMutex.lock();
            m_ShowImage = QImage((uchar*)pBuffer,m_pFrame.iWidth, m_pFrame.iHeight,m_pFrame.iWidth*3, QImage::Format_RGB888,0,0);
            m_ShowImage = m_ShowImage.rgbSwapped();
            m_threadMutex.unlock();
            emit dispSignal();
        }
    }
}


























